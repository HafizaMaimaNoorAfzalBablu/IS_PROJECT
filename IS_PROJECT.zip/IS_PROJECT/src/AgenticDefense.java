import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.*;

public class AgenticDefense extends JFrame {
    private int failCount = 0;
    private long lastAttemptTime = System.currentTimeMillis();
    private int trustScore = 0;
    private int riskScore = 0;

    private JTextField userField;
    private JPasswordField passField;
    private JLabel riskLabel;
    private JProgressBar riskBar;
    private JTextArea logArea;

    public AgenticDefense() {
        // High-Tech Dark Theme
        setTitle("AGENTIC COMMAND CENTER v1.0");
        setSize(500, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(10, 10, 10));
        setLayout(new BorderLayout(10, 10));

        // 1. Header
        JLabel header = new JLabel("AGENTIC LOGIN DEFENSE", SwingConstants.CENTER);
        header.setForeground(new Color(255, 0, 0));
        header.setFont(new Font("Monospaced", Font.BOLD, 28));
        header.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        add(header, BorderLayout.NORTH);

        // 2. Main Login Panel
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(new Color(15, 15, 15));
        centerPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(255, 0, 0, 100), 2),
                BorderFactory.createEmptyBorder(30, 50, 30, 50)
        ));

        // Styled Inputs
        userField = createStyledTextField("Username");
        passField = createStyledPasswordField();

        JButton loginBtn = new JButton("INITIATE SECURE LOGIN");
        styleButton(loginBtn);

        riskBar = new JProgressBar(0, 100);
        riskBar.setValue(0);
        riskBar.setStringPainted(true);
        riskBar.setForeground(Color.RED);
        riskBar.setBackground(Color.DARK_GRAY);

        riskLabel = new JLabel("THREAT LEVEL: NEUTRAL", SwingConstants.CENTER);
        riskLabel.setForeground(Color.CYAN);
        riskLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(userField);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        centerPanel.add(passField);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        centerPanel.add(loginBtn);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 25)));
        centerPanel.add(riskLabel);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        centerPanel.add(riskBar);

        add(centerPanel, BorderLayout.CENTER);

        // 3. Terminal Log
        logArea = new JTextArea(10, 20);
        logArea.setEditable(false);
        logArea.setBackground(Color.BLACK);
        logArea.setForeground(new Color(0, 255, 0));
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JScrollPane scroll = new JScrollPane(logArea);
        scroll.setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.GRAY), "SYSTEM_LOGS", 0, 0, null, Color.GRAY));
        add(scroll, BorderLayout.SOUTH);

        loginBtn.addActionListener(e -> handleLogin());
    }

    private void handleLogin() {
        long now = System.currentTimeMillis();
        double gap = (now - lastAttemptTime) / 1000.0;
        lastAttemptTime = now;

        // Reset base risk logic from your data
        riskScore = (failCount * 15);

        if (gap < 2.0) riskScore += 40; // Bot Speed Factor
        riskScore -= (trustScore * 5);  // Trust Factor

        riskScore = Math.max(0, Math.min(100, riskScore));

        riskBar.setValue(riskScore);
        updateStatus(riskScore);

        if (riskScore >= 75) {
            logArea.append("> ALERT: AGENTIC BLOCK TRIGGERED. BOT PATTERN DETECTED.\n");
            JOptionPane.showMessageDialog(this, "SYSTEM LOCKOUT: Agentic Defense Active.", "SECURITY ALERT", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Logic check matching your users.txt
        String enteredUser = userField.getText();
        String enteredPass = new String(passField.getPassword());

        if (enteredUser.equals("admin") && enteredPass.equals("admin@456")) {
            trustScore++;
            failCount = 0;
            logArea.append("> ACCESS GRANTED. Trust Reputation Increased.\n");
        } else {
            failCount++;
            logArea.append("> ACCESS DENIED. Suspicion Level Rising...\n");
        }
    }

    private void updateStatus(int score) {
        if (score < 30) { riskLabel.setText("THREAT LEVEL: LOW"); riskLabel.setForeground(Color.GREEN); }
        else if (score < 70) { riskLabel.setText("THREAT LEVEL: ELEVATED"); riskLabel.setForeground(Color.ORANGE); }
        else { riskLabel.setText("THREAT LEVEL: CRITICAL"); riskLabel.setForeground(Color.RED); }
    }

    private JTextField createStyledTextField(String text) {
        JTextField f = new JTextField(text);
        f.setBackground(new Color(30, 30, 30));
        f.setForeground(Color.WHITE);
        f.setCaretColor(Color.RED);
        f.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        return f;
    }

    private JPasswordField createStyledPasswordField() {
        JPasswordField f = new JPasswordField("Password");
        f.setBackground(new Color(30, 30, 30));
        f.setForeground(Color.WHITE);
        f.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        return f;
    }

    private void styleButton(JButton btn) {
        btn.setBackground(new Color(150, 0, 0));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 14));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AgenticDefense().setVisible(true));
    }
}