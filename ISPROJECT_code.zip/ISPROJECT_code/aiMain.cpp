#include <iostream>
#include <string>
#include <iomanip>
#include <ctime>
#include <cstdlib>
#include <conio.h>
#include <windows.h>
#include <cmath>
#include <fstream>
#include <vector>
using namespace std;
const string RED = "\x1B[31m";
const string GREEN = "\x1B[32m";
const string YELLOW = "\x1B[33m";
const string CYAN = "\x1B[36m";
const string RESET = "\x1B[0m";
struct UserSession
{
    string username;
    int failureCount;
    double lastAttemptTime;
    double avgSpeed;
    double lastGap;
    int riskScore;
    int trustScore;
    int lockLevel;
    bool wasBlocked;
};
vector<string> validUsernames;
vector<string> validPasswords;
void logAttempt(string user, int risk, bool success)
{
    time_t now = time(0);
    char *dt = ctime(&now);
    string timestamp(dt);
    if (!timestamp.empty())
    {
        timestamp.pop_back();
    }
    string logUser;
    if (user.empty())
    {
        logUser = "unknown";
    }
    else
    {
        logUser = user;
    }
    ofstream file("log.txt", ios::app);
    file << "[" << timestamp << "] User: " << logUser
         << " | Risk: " << risk
         << " | Result: ";
    if (success)
    {
        file << "SUCCESS";
    }
    else
    {
        file << "FAIL";
    }
    file << endl;
    file.close();
}
void loadUsersFromFile()
{
    ifstream file("users.txt");
    string u, p;
    validUsernames.clear();
    validPasswords.clear();
    if (file.is_open())
    {
        while (file >> u >> p)
        {
            validUsernames.push_back(u);
            validPasswords.push_back(p);
        }
        file.close();
    }
    else
    {
        validUsernames = {"maima", "admin", "sadia"};
        validPasswords = {"pass123", "admin@456", "sadia567"};
    }
}
void loading(string text)
{
    cout << CYAN << "\n"
         << text;
    for (int i = 0; i < 8; i++)
    {
        cout << "." << flush;
        Sleep(300);
    }
    cout << RESET << "\n";
}
void thinkingMode()
{
    cout << YELLOW << "\n[SECURITY ENGINE] Processing";
    for (int i = 0; i < 10; i++)
    {
        cout << "." << flush;
        Sleep(200);
    }
    cout << RESET << "\n";
}
void printHeader()
{
    system("cls");
    cout << CYAN;
    cout << "=========================================\n";
    cout << "   AI-BASED ADAPTIVE LOGIN DEFENSE       \n";
    cout << "=========================================\n";
    cout << RESET << endl;
}
void showDashboard(string user, int risk)
{
    cout << CYAN;
    cout << "=========================================\n";
    cout << "         SECURITY ANALYSIS DASHBOARD      \n";
    cout << "=========================================\n";
    cout << RESET;
    cout << "User Detected      : " << user << "\n";
    cout << "Risk Score         : " << risk << " / 100\n";
    cout << "-----------------------------------------\n";
    if (risk < 40)
    {
        cout << GREEN << "Status             : SAFE USER\n";
        cout << "Action             : NORMAL LOGIN\n";
    }
    else if (risk < 70)
    {
        cout << YELLOW << "Status             : SUSPICIOUS ACTIVITY\n";
        cout << "Action             : CAPTCHA / DELAY\n";
    }
    else
    {
        cout << RED << "Status             : HIGH RISK ATTACK\n";
        cout << "Action             : ACCOUNT BLOCKED\n";
    }
    cout << RESET << "\n=========================================\n";
}
string getHiddenPassword()
{
    string pass = "";
    char ch;
    while (true)
    {
        ch = _getch();
        if (ch == '\r')
            break;
        if (ch == '\b' && pass.length() > 0)
        {
            pass.pop_back();
            cout << "\b \b";
        }
        else if (ch != '\b')
        {
            pass += ch;
            cout << "*";
        }
    }
    cout << endl;
    return pass;
}
bool isValidUser(string u, string p)
{
    for (size_t i = 0; i < validUsernames.size(); i++)
    {
        if (validUsernames[i] == u && validPasswords[i] == p)
        {
            return true;
        }
    }
    return false;
}
bool isUnknownUser(string u)
{
    for (size_t i = 0; i < validUsernames.size(); i++)
    {
        if (validUsernames[i] == u)
        {
            return false;
        }
    }
    return true;
}
int calculateRiskScore(UserSession s)
{
    int score = 0;
    if (s.failureCount >= 10)
    {
        score += 70;
    }
    else if (s.failureCount >= 5)
    {
        score += 40;
    }
    else if (s.failureCount >= 3)
    {
        score += 20;
    }
    if (s.avgSpeed < 2.0)
    {
        score += 30;
    }
    else if (s.avgSpeed < 5.0)
    {
        score += 15;
    }
    if (s.avgSpeed < 99 && abs(s.avgSpeed - s.lastGap) < 0.2)
    {
        score += 25;
    }
    score -= s.trustScore * 2;
    if (score < 0)
    {
        score = 0;
    }
    if (score > 100)
    {
        score = 100;
    }
    return score;
}
bool solveCaptcha(int type)
{
    int a = rand() % 10 + 1;
    int b = rand() % 10 + 1;
    int c = rand() % 5 + 1;
    int ans;
    cout << YELLOW << "\n[CAPTCHA] Solve: ";
    if (type == 1)
    {
        cout << a << " + " << b << " = ";
    }
    else
    {
        cout << "(" << a << " * " << b << ") + " << c << " = ";
    }
    if (!(cin >> ans))
    {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << RED << "Invalid input!\n"
             << RESET;
        return false;
    }
    cin.ignore(1000, '\n');
    if (type == 1)
    {
        return ans == (a + b);
    }
    else
    {
        return ans == (a * b + c);
    }
}
bool verify2FA()
{
    int code = rand() % 8999 + 1000;
    int userCode;
    cout << YELLOW << "\n[2FA] A security code has been sent: " << RED << code << RESET << endl;
    cout << "Enter the 4-digit code: ";
    if (!(cin >> userCode))
    {
        cin.clear();
        cin.ignore(1000, '\n');
        return false;
    }
    cin.ignore(1000, '\n');
    return (userCode == code);
}
void decideAction(UserSession &s)
{
    thinkingMode();
    s.riskScore = calculateRiskScore(s);
    if (s.wasBlocked)
    {
        if (100 < 80 + (s.lockLevel * 5))
        {
            s.riskScore = 100;
        }
        else
        {
            s.riskScore = 80 + (s.lockLevel * 5);
        }
    }
    cout << CYAN << "\nRisk Score: " << s.riskScore << "/100\n"
         << RESET;
    if (s.riskScore >= 70)
    {
        s.lockLevel++;
        s.wasBlocked = true;
        int lockTime;
        if (s.lockLevel == 1)
        {
            lockTime = 10;
        }
        else if (s.lockLevel == 2)
        {
            lockTime = 12;
        }
        else if (s.lockLevel == 3)
        {
            lockTime = 15;
        }
        else
        {
            lockTime = 20;
        }
        cout << RED << "\nHIGH RISK DETECTED\n";
        cout << "Security Level: " << s.lockLevel << "\n";
        cout << "System Lock Activated\n\n";
        for (int i = lockTime; i > 0; i--)
        {
            cout << "\rLOCK ACTIVE... " << i << " seconds remaining   " << flush;
            Sleep(1000);
        }
        cout << "\n\nSystem Unlocked. Try again.\n"
             << RESET;
        s.failureCount = 0;
        s.avgSpeed = 99;
        if (0 > s.trustScore - 1)
        {
            s.trustScore = 0;
        }
        else
        {
            s.trustScore = s.trustScore - 1;
        }
    }
    else if (s.riskScore >= 40)
    {
        loading("Applying security delay");
        solveCaptcha(2);
    }
    else if (s.riskScore > 0)
    {
        solveCaptcha(1);
    }
    showDashboard(s.username, s.riskScore);
}
void loginSystem()
{
    UserSession s;
    s.failureCount = 0;
    s.lastAttemptTime = 0;
    s.avgSpeed = 99;
    s.lastGap = 0;
    s.riskScore = 0;
    s.trustScore = 0;
    s.lockLevel = 0;
    s.wasBlocked = false;
    string u, p;
    double currentTime, gap;
    loading("Initializing Security Engine");
    while (true)
    {
        cout << "\nUsername: ";
        cin >> u;
        s.username = u;
        cout << "Password: ";
        p = getHiddenPassword();
        currentTime = (double)clock() / CLOCKS_PER_SEC;
        if (s.lastAttemptTime == 0)
        {
            gap = 99;
        }
        else
        {
            gap = currentTime - s.lastAttemptTime;
        }
        s.lastGap = gap;
        if (s.failureCount > 0)
        {
            s.avgSpeed = (s.avgSpeed + gap) / 2;
        }
        s.lastAttemptTime = currentTime;
        if (isValidUser(u, p))
        {
            if (verify2FA())
            {
                s.trustScore++;
                s.wasBlocked = false;
                s.lockLevel = 0;
                cout << GREEN << "\nACCESS GRANTED\n";
                cout << "CONGRATULATIONS!\n"
                     << RESET;
                loading("Opening Secure Session");
                showDashboard(s.username, 0);
                logAttempt(u, 0, true);
                break;
            }
            else
            {
                cout << RED << "\n2FA FAILED\n"
                     << RESET;
                s.failureCount++;
                decideAction(s);
                logAttempt(u, s.riskScore, false);
            }
        }
        else
        {
            s.failureCount++;
            if (isUnknownUser(u))
            {
                s.failureCount += 1;
            }
            cout << RED << "\nAUTH FAILED\n"
                 << RESET;
            decideAction(s);
            logAttempt(u, s.riskScore, false);
        }
    }
}
void simulateAttack()
{
    UserSession s;
    s.username = "attacker_bot";
    s.failureCount = 0;
    s.avgSpeed = 0.3;
    s.lastGap = 0.3;
    s.riskScore = 0;
    s.trustScore = 0;
    s.lockLevel = 0;
    s.wasBlocked = false;
    s.lastAttemptTime = 0;
    string botPasswords[10] = {
        "123456",
        "admin",
        "password",
        "admin123",
        "letmein",
        "qwerty",
        "abc123",
        "root",
        "toor",
        "pass123"};
    cout << RED;
    cout << "=========================================\n";
    cout << "      BRUTE FORCE ATTACK SIMULATION      \n";
    cout << "=========================================\n";
    cout << RESET;
    cout << YELLOW;
    cout << "\n[BOT INFO]\n";
    cout << "  Target Username : admin\n";
    cout << "  Attack Type     : Brute Force\n";
    cout << "  Bot Speed       : 0.3 sec per attempt\n";
    cout << "  Password List   : Common passwords\n";
    cout << RESET;
    cout << CYAN << "\n[SYSTEM] Monitoring started...\n"
         << RESET;
    Sleep(1500);
    for (int i = 0; i < 10; i++)
    {
        Sleep(300);
        s.failureCount++;
        s.riskScore = calculateRiskScore(s);
        cout << CYAN << "\n[ATTEMPT " << i + 1 << "]" << RESET;
        cout << " Target: admin";
        cout << " | Password tried: " << botPasswords[i];
        cout << " | Speed: 0.3s";
        cout << " | Risk: ";
        if (s.riskScore >= 70)
        {
            cout << RED << s.riskScore << "/100" << RESET;
        }
        else if (s.riskScore >= 40)
        {
            cout << YELLOW << s.riskScore << "/100" << RESET;
        }
        else
        {
            cout << GREEN << s.riskScore << "/100" << RESET;
        }
        if (s.riskScore >= 70)
        {
            cout << RED << "\n\n=========================================\n";
            cout << "   ATTACK DETECTED & BLOCKED!            \n";
            cout << "   Bot identified by behavioral engine.  \n";
            cout << "   Reason : Abnormal speed + failures    \n";
            cout << "   Action : Account locked               \n";
            cout << "=========================================\n";
            cout << RESET;
            int lockTime = 10;
            for (int j = lockTime; j > 0; j--)
            {
                cout << "\rLOCK ACTIVE... " << j
                     << " seconds remaining   " << flush;
                Sleep(1000);
            }
            cout << endl;
            break;
        }
        else
        {
            cout << RED << " -> [FAILED]" << RESET;
        }
    }
    showDashboard(s.username, s.riskScore);
    cout << GREEN;
    cout << "\n[RESULT] Simulation complete!\n";
    cout << "  Bot was successfully detected\n";
    cout << "  and blocked by the adaptive system.\n";
    cout << RESET;
}
int main()
{
    srand(time(0));
    loadUsersFromFile();
    int choice;
    while (true)
    {
        printHeader();
        cout << "1. Login System\n";
        cout << "2. Simulate Attack\n";
        cout << "3. Exit\n";
        cout << "Choice: ";
        if (!(cin >> choice))
        {
            cin.clear();
            cin.ignore(1000, '\n');
            continue;
        }
        if (choice == 1)
        {
            loginSystem();
        }
        else if (choice == 2)
        {
            simulateAttack();
        }
        else if (choice == 3)
        {
            cout << CYAN << "\nThank you for using the Adaptive Login Defense system!" << RESET << endl;
            cout << "Stay secure. Exiting..." << endl;
            Sleep(1500);
            break;
        }
        cout << "\nPress any key...";
        _getch();
    }
    return 0;
}